<!---Custom_textbox creation----->
<?php 

  global $wpdb;
  $table_name = $wpdb->prefix . 'bp_new_manager';
 
  //1st DB
  if (isset($_POST['uptsubmit'])) {
    $id = $_POST['uptid'];
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $uid = $_POST['uid'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];
    $desig = $_POST['desig'];

    

    $wpdb->query("UPDATE $table_name SET fname='$fname', lname ='$lname', uid='$uid',email='$email',mobile='$mobile',desig='$desig' WHERE user_id='$id'");
    echo "<script>location.replace('admin.php?page=edit_manager');</script>";
  }
 ?>



















<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
    <link rel="icon" type="image/png" href="../assets/img/favicon.png">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>   </title>
    <meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
    <!--     Fonts and icons     -->
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
    <!-- CSS Files -->
     <!-- CSS Files -->
      <link href="../assets/css/material-dashboard.css?v=2.1.2" rel="stylesheet" />
      <!-- CSS Just for demo purpose, don't include it in your project -->
    <style>
      
      input[type=submit] {
        background-color: #33cccc;
        color: white;
        padding: 5px 20px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        float: right;
        }

        input[type=submit]:hover {
          background-color: #03fcf4;
        }
        .table{

        }
        .table thead tr th, .table tbody tr td {
            border: none;

        }
        .button{
          border: none;
        }

    </style>  
    
  </head>
  <body class="">
    <div class="wrapper ">
      <div class="sidebar" data-color="azure" data-background-color="white" data-image="../assets/img/sidebar-1.jpg">
        <!--
        Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"
        Tip 2: you can also add an image using data-image tag
        -->

        <div class="logo "><a href="#" class="simple-text logo-normal ">
        Project Purchase Plugin
        </a></div>
        <div class="sidebar-wrapper ">
          <ul class="nav">
            <li class="nav-item   ">
            <a class="nav-link" href="<?php echo admin_url('admin.php?page=wpplugin') ?>">
              <i class="material-icons">dashboard</i>
              <p>Home</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="<?php echo admin_url('admin.php?page=add_new_manager') ?>">
              <i class="material-icons">bubble_chart</i>
              <p>Add New Manager </p>
            </a>
          </li>
          <li class="nav-item  ">
            <a class="nav-link" href="<?php echo admin_url('admin.php?page=create_new_project') ?>">
              <i class="material-icons">content_paste</i>
              <p>Create New Project</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="<?php echo admin_url('admin.php?page=edit_project') ?>">
              <i class="material-icons">content_paste</i>
              <p>Edit Project</p>
            </a>
          </li>
          <li class="nav-item active ">
            <a class="nav-link" href="<?php echo admin_url('admin.php?page=edit_manager') ?>">
              <i class="material-icons">content_paste</i>
              <p>Edit Project Manager</p>
            </a>
          </li>

          </ul>
        </div>
      </div>
      <div class="main-panel">
      
            <div class="container-fluid ml-5">
                 
               <div class="card " style="width: 100%;">
                      
                   <h2 class=" m-5"><b>Edit Manager</b></h2>
                    <div class="ml-4 mr-5">
                       <form action="" method="post">
                          
                          <div class="form-group row">
                            <div class="col-9 ">
                             
                             <input type="text" class="form-control" id="search" name="search" placeholder="Search by  Name or ID" required>
                            </div>
                            <div class="col-3">
                            
                              <input type="submit" name="submit" value="Search">
                              
                                <!---<button type="button" class="btn btn-info" name="submit">Search</button>
                                --->
                            </div>
                          </div>
                       </form>
                       <!------Show result---------->
                   <table  class="table table-responsive borderless mt-3">
                        
                        
                        <!----Search result---->
                        <?php
                        if (isset($_POST['submit'])) {


                          $search_value=$_POST["search"];
                          
                          global $wpdb;
                          $table_name = $wpdb->prefix . 'bp_new_manager';
                          $result = $wpdb->get_results ( "SELECT * FROM  $table_name WHERE uid like '%$search_value%' OR fname like '%$search_value%' OR lname like '%$search_value%' " );
                          $no_src_res =$wpdb->get_var ( "SELECT count(*) FROM  $table_name WHERE uid like '%$search_value%' OR fname like '%$search_value%' OR lname like '%$search_value%'" );
                              
                          foreach ( $result as $print ) {

                          ?>
                            <tr>
                              <!----
                              <td><?php echo "Search Value: ".$search_value; ?></td>
                              --->
                
                              <td><?php echo "Search Result: ".$no_src_res; ?></td>
                            </tr>
                            
                            <!---------------->
                            <tr > 
                              <td>First Name</td>
                              <td></td><td></td><td></td><td></td>
                              <td><?php echo $print->fname;?></td>
                            </tr>
                            <tr> 
                              <td>Last Name</td>
                              <td></td><td></td><td></td><td></td>
                              <td><?php echo $print->lname;?></td>
                            </tr>
                            <tr > 
                              <td>User ID</td>
                              <td></td><td></td><td></td><td></td>
                              <td><?php echo $print->uid;?></td>
                            </tr>
                            <tr> 
                              <td>Email</td>
                              <td></td><td></td><td></td><td></td>
                              <td><?php echo $print->email;?></td>
                            </tr>
                            <tr > 
                              <td>Mobile</td>
                              <td></td><td></td><td></td><td></td>
                              <td><?php echo $print->mobile;?></td>
                            </tr>
                            <tr> 
                              <td>Designation</td>
                              <td></td><td></td><td></td><td></td>
                              <td><?php echo $print->desig;?></td>
                            </tr>
                            <tr> 
                              <td></td>
                              <td></td><td></td><td></td><td></td>
                              <td ><a href='admin.php?page=edit_manager&upt=<?php echo"$print->user_id";?>'><button type='button' class="btn btn-info" style='color: white; background-color: #03dbfc;border-radius: 5px;'>Edit Manager</button></a></td>
                            </tr>
                          <?php
                          } //----foreach loop ends

                        }
                        ?>
                      </table>
                    </div>  
                </div>



               
                  <!-----Update part2------>
                                <?php
                                if (isset($_GET['upt'])) {
                                  $upt_id = $_GET['upt'];
                                  $result = $wpdb->get_results("SELECT * FROM $table_name WHERE user_id='$upt_id'");
                                  foreach($result as $print) {
                                    
                                    $fname = $print->fname;
                                    $lname = $print->lname;
                                    $uid = $print->uid;
                                    $email = $print->email;
                                    $mobile = $print->mobile;
                                    $desig = $print->desig;
                                    
                                
                                   
                                  }

                                
                               ?>  
                               <div class="card">
                                        
                                <table >


                                <form action="" method="post">
                                            
                                 
                                  <div class="form-group row">
                                  <div class="col-12">
                                   <h3>Update Manager</h3>
                                  </div>
                                  
                                </div>

                                <!-------User Id-------->
                                <td width='20%'><input type='hidden' id='uptid' name='uptid' value='<?php echo $print->user_id; ?>'></td>
                                <!-------1------>
                                <div class="form-group row">
                                  <div class="col-6">
                                   <h4>First Name</h4>
                                  </div>
                                  <div class="col-6">
                                    <input type="text" class="form-control" id="fname" name="fname" value="<?php echo $fname; ?>" required>
                                  </div>
                                </div>
                                 <!-------2------>
                                <div class="form-group row">
                                  <div class="col-6">
                                   <h4>Last Name</h4>
                                  </div>
                                  <div class="col-6">
                                    <input type="text" class="form-control" id="laname" name="lname" value="<?php echo $lname;?>" required>
                                  </div>
                                </div>
                                 <!-------3------>
                                <div class="form-group row">
                                  <div class="col-6">
                                   <h4>User ID</h4>
                                  </div>
                                  <div class="col-6">
                                    <input type="text" class="form-control" id="uid" name="uid" value="<?php echo $uid;?>" readonly required>
                                  </div>
                                </div>
                                 <!-------4------>
                                <div class="form-group row">
                                  <div class="col-6">
                                   <h4>Email</h4>
                                  </div>
                                  <div class="col-6">
                                    <input type="text" class="form-control" id="email" name="email" value="<?php echo $email;?>" required>
                                  </div>
                                </div>
                              
                                 <!-------5------>
                                <div class="form-group row">
                                  <div class="col-6">
                                   <h4>Mobile No.</h4>
                                  </div>
                                  <div class="col-6">
                                    <input type="text" class="form-control" id="mobile" name="mobile" value="<?php echo $mobile;?>" required>
                                  </div>
                                </div>
                                <!-------6------>
                                <div class="form-group row">
                                  <div class="col-6">
                                   <h4>Designation</h4>
                                  </div>
                                  <div class="col-6">
                                    <input type="text" class="form-control" id="desig" name="desig" value="<?php echo $desig;?>" required>
                                  </div>
                                </div>
                                <!------Submit------>
                                <div class="form-group row ">
                                  <div class="col-6">
                                   
                                   </div>
                                   <div class="col-6">
                                     <button id='uptsubmit' name='uptsubmit' type='submit' style='color: white; background-color: #33cccc; border-radius: 5px;'>UPDATE</button>
                                     <a href='admin.php?page=edit_manger'><button type='button'>CANCEL</button></a>
                                   </div>
                                 </div>
                                              
                                           
                                            
                                    </form>
                                  </table>";
                              </div>

                          <?php } ?> <!--------Update ends----->
               

                











            </div>
            </div>
            </div>
          
    <!--   Core JS Files   -->
    
    
    















  </body>
</html>