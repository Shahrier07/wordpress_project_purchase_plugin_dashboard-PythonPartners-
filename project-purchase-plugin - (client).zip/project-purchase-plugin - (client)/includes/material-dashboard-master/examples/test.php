<!---Custom_textbox creation----->
<?php 

  global $wpdb;
  $table_name = $wpdb->prefix . 'bp_new_project';
 
  //1st DB
  if (isset($_POST['newsubmit'])) {
    $pname = $_POST['pname'];
    $pid = $_POST['pid'];
    $pmng = $_POST['pmng'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];
    $budget = $_POST['budget'];

    $wpdb->query("INSERT INTO $table_name(pname,pid,pmng,start_date,end_date,budget) VALUES('$pname','$pid','$pmng','$start_date','$end_date',' $budget')");
    echo "<script>location.replace('admin.php?page=create_new_project');</script>";
  }
  
 
  
  
 

 ?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
    <link rel="icon" type="image/png" href="../assets/img/favicon.png">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <title>   </title>
    <meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
    <!--     Fonts and icons     -->
    <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
    <!-- CSS Files -->
     <!-- CSS Files -->
      <link href="../assets/css/material-dashboard.css?v=2.1.2" rel="stylesheet" />
      <!-- CSS Just for demo purpose, don't include it in your project -->
     
    
  </head>
  <body class="">
    <div class="wrapper ">
      <div class="sidebar" data-color="azure" data-background-color="white" data-image="../assets/img/sidebar-1.jpg">
        <!--
        Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"
        Tip 2: you can also add an image using data-image tag
        -->

        <div class="logo "><a href="#" class="simple-text logo-normal ">
        Project Purchase Plugin
        </a></div>
        <div class="sidebar-wrapper ">
          <ul class="nav">
            <li class="nav-item   ">
            <a class="nav-link" href="<?php echo admin_url('admin.php?page=wpplugin') ?>">
              <i class="material-icons">dashboard</i>
              <p>Home</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="<?php echo admin_url('admin.php?page=add_new_manager') ?>">
              <i class="material-icons">bubble_chart</i>
              <p>Add New Manager </p>
            </a>
          </li>
          <li class="nav-item active ">
            <a class="nav-link" href="<?php echo admin_url('admin.php?page=create_new_project') ?>">
              <i class="material-icons">content_paste</i>
              <p>Create New Project</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="<?php echo admin_url('admin.php?page=edit_project') ?>">
              <i class="material-icons">content_paste</i>
              <p>Edit Project</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="<?php echo admin_url('admin.php?page=edit_manager') ?>">
              <i class="material-icons">content_paste</i>
              <p>Edit Project Manager</p>
            </a>
          </li>

          </ul>
        </div>
      </div>
      <div class="main-panel">
      
            <div class="container-fluid ml-5">
                 
               <div class="card " style="width: 100%;">
                      
                   <h2 class=" m-5"><b>Create New Project</b></h2>
                    <div class="ml-5 mr-5">
                       <form action="" method="post">
                          <!-------1------>
                          <div class="form-group row">
                            <div class="col-6">
                             <h4>Project Name</h4>
                            </div>
                            <div class="col-6">
                              <input type="text" class="form-control" id="pname" name="pname" placeholder="project name..." required>
                            </div>
                          </div>
                           <!-------2------>
                          <div class="form-group row">
                            <div class="col-6">
                             <h4>Project ID</h4>
                            </div>
                            <div class="col-6">
                              <input type="text" class="form-control" id="pid" name="pid" placeholder="project id" required>
                            </div>
                          </div>
                           <!-------3------>
                          <div class="form-group row">
                            <div class="col-6">
                             <h4>Project Manager</h4>
                            </div>
                            <div class="col-6" style="width: 100%;">
                              <!----
                              <input type="text" class="form-control" id="pmng" name="pmng"placeholder="project manager..." >
                              --->
                              <select name="pmng" id="pmng" class="form-select form-select-lg mb-lg-3" aria-label="Default select example" required>
                                            <option value= "" selected>Select Manager</option>
                                            <option value="Nahin Mamun">Nahin Mamun</option>
                                            <option value="Shahrier Sarder">Shahrier Sarder</option>
                                            
                               </select>
                            </div>
                          </div>
                           <!-------4------>
                          <div class="form-group row">
                            <div class="col-6">
                             <h4>Start Date</h4>
                            </div>
                            <div class="col-6">
                              <?php $today = date('Y-m-d'); 
                                //echo $today;
                              ?>

                              <input type="date" class="form-control" id="start_date" name="start_date"
                              value="" min="<?php  echo $today;?>" max="" required>
                            </div>
                          </div>
                        
                           <!-------5------>
                          <div class="form-group row">
                            <div class="col-6">
                             <h4>End Date</h4>
                            </div>
                            <div class="col-6">
                              <?php $today = date('Y-m-d'); 
                                //echo $today;
                              ?>

                              <input type="date" class="form-control" id="end_date" name="end_date"
                              value= "" min= "<?php  echo $today;?>" max="" required>
                            </div>
                          </div>
                          <!-------6------>
                          <div class="form-group row">
                            <div class="col-6">
                             <h4>Budget</h4>
                            </div>
                            <div class="col-6">
                              <input type="number" class="form-control" id="budget" name="budget" placeholder="budget..." required>
                            </div>
                          </div>
                          <div class="form-group row ">
                            <div class="col-6">
                             
                            </div>
                            <div class="col-6">
                              <button class="btn btn-info " id="newsubmit" name="newsubmit" type="submit">Create Project</button>
                            </div>
                            
                          </div>
                          
                      </form>
                    </div>  
                </div>












            </div>
            </div>
            </div>
          
    <!--   Core JS Files   -->
    
    
    















  </body>
</html>