<!--
=========================================================
Material Dashboard - v2.1.2
=========================================================
 -->




<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="../assets/img/favicon.png">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <title>
    Project Purchase Plugin Plugin by Python Partners
  </title>
  <meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Roboto+Slab:400,700|Material+Icons" />
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css">
  <!-- CSS Files -->
  <link href="../assets/css/material-dashboard.css?v=2.1.2" rel="stylesheet" />
  <!-- CSS Just for demo purpose, don't include it in your project -->
  <link href="../assets/demo/demo.css" rel="stylesheet" />
</head>

<body class="">
  <div class="wrapper ">
    <div class="sidebar" data-color="azure" data-background-color="" data-image="../assets/img/sidebar-1.jpg">
      <!--
        Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

        Tip 2: you can also add an image using data-image tag
    -->
      <div class="logo"><a href="#" class="simple-text logo-normal">
         Project Purchase Plugin 
        </a></div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li class="nav-item active  ">
            <a class="nav-link" href="#">
              <i class="material-icons">dashboard</i>
              <p>Home</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="<?php echo admin_url('admin.php?page=add_new_manager') ?>">
              <i class="material-icons">bubble_chart</i>
              <p>Add New Manager </p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="<?php echo admin_url('admin.php?page=create_new_project') ?>">
              <i class="material-icons">content_paste</i>
              <p>Create New Project</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="<?php echo admin_url('admin.php?page=edit_project') ?>">
              <i class="material-icons">content_paste</i>
              <p>Edit Project</p>
            </a>
          </li>
          <li class="nav-item ">
            <a class="nav-link" href="<?php echo admin_url('admin.php?page=edit_manager') ?>">
              <i class="material-icons">content_paste</i>
              <p>Edit Project Manager</p>
            </a>
          </li>
         

      
          
         
         
        </ul>
      </div>
    </div>
    <div class="main-panel">
    
      <!-- End Navbar -->
      <div class="content">
        <div class="container-fluid">
                
          <!---------1st----------->
         <div class="container-fluid">
          <h2 class=" mr-5 ml-5"><b>Project Procurement Plugin by Python Partners</b></h2>


            <div class="jumbotron mt-5 m-5">     
              <h5>Use this plugin to create new projects and then select the project name in Add New Product Page.</h5>
              <br>

              <h5>By using this plugin can record project details to a product before purchasing and get further analytics with Procure Partners.
              </h5>
            </div>
                 
          </div>
              
          
          
            
         </div>
        </div>
      </div>
      
    </div>

 
  
 
  
</body>

</html>