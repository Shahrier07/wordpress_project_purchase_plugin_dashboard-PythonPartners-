<?php

function bus_procure_dashboard_pages()
{
  add_menu_page(
    __( 'Project Purchase Plugin', 'wpplugin' ),
    __( 'Project Purchase Plugin', 'wpplugin' ),
    'manage_options',
    'wpplugin', //slug
    'bus_procure_settings_page_markup',
    'dashicons-wordpress-alt',
    3
  );
  add_submenu_page(
    'wpplugin',
    __( 'Plugin Feature 1', 'wpplugin' ),
    __( 'Add New Manager', 'wpplugin' ),
    'manage_options',
    'add_new_manager',
    'add_new_manager_markup'
  );

  add_submenu_page(
    'wpplugin',
    __( 'Plugin Feature 2', 'wpplugin' ),
    __( 'Create New Project', 'wpplugin' ),
    'manage_options',
    'create_new_project',
    'create_new_project_markup'
  );
  add_submenu_page(
    'wpplugin',
    __( 'Plugin Feature 3', 'wpplugin' ),
    __( 'Edit Project', 'wpplugin' ),
    'manage_options',
    'edit_project',
    'edit_project_markup'
  );
  add_submenu_page(
    'wpplugin',
    __( 'Plugin Feature 4', 'wpplugin' ),
    __( 'Edit Project Manager', 'wpplugin' ),
    'manage_options',
    'edit_manager',
    'edit_manager_markup'
  );
  
     

}
add_action( 'admin_menu', 'bus_procure_dashboard_pages' );

// Add a link to your settings page in your plugin
function bus_procure_add_settings_link( $links ) {
    $settings_link = '<a href="admin.php?page=wpplugin">' . __( 'Settings' ) . '</a>';
    array_push( $links, $settings_link );
    return $links;
}
$filter_name = "plugin_action_links_" . plugin_basename( __FILE__ );

add_filter( $filter_name, 'bus_procure_add_settings_link' );

function bus_procure_settings_page_markup()
{
  // Double check user capabilities
  if ( !current_user_can('manage_options') ) {
      return;
  }else{
    include( plugin_dir_path( __FILE__ ) . 'material-dashboard-master/examples/dashboard.php'); 
    //include( plugin_dir_path( __FILE__ ) . 'custom_dashboard/index.html'); 
  }
}


///==================




function add_new_manager_markup()
{
    include( plugin_dir_path( __FILE__ ) . 'material-dashboard-master/examples/add_new_manager.php');
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    $table_name = $wpdb->prefix . 'bp_new_manager';
    $sql = "CREATE TABLE `$table_name` (
    `user_id` int(11) NOT NULL AUTO_INCREMENT,
    `fname` varchar(220) DEFAULT NULL,
    `lname` varchar(220) DEFAULT NULL,
    `uid` varchar(220) DEFAULT NULL,
    `email` varchar(220) DEFAULT NULL,
    `mobile` varchar(220) DEFAULT NULL,
    `desig` varchar(220) DEFAULT NULL,

    PRIMARY KEY(user_id)
    ) ENGINE=MyISAM DEFAULT CHARSET=latin1;
    ";
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
      require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
      dbDelta($sql);
    }
}

function create_new_project_markup()
{
    include( plugin_dir_path( __FILE__ ) . 'material-dashboard-master/examples/create_new_project.php');
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    $table_name = $wpdb->prefix . 'bp_new_project';
    $sql = "CREATE TABLE `$table_name` (
    `user_id` int(11) NOT NULL AUTO_INCREMENT,
    `pname` varchar(220) DEFAULT NULL,
    `pid` varchar(220) DEFAULT NULL,
    `pmng` varchar(220) DEFAULT NULL,
    `start_date` varchar(220) DEFAULT NULL,
    `end_date` varchar(220) DEFAULT NULL,
    `budget` int(100) DEFAULT NULL,
    PRIMARY KEY(user_id)
    ) ENGINE=MyISAM DEFAULT CHARSET=latin1;
    ";
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
      require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
      dbDelta($sql);
    }
}
function edit_project_markup()
{
    include( plugin_dir_path( __FILE__ ) . 'material-dashboard-master/examples/edit_project.php');
    
}
function edit_manager_markup()
{
    include( plugin_dir_path( __FILE__ ) . 'material-dashboard-master/examples/edit_manager.php');
   
}
///=================================///

?>